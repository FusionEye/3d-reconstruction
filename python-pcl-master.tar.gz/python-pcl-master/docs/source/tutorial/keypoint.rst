KeyPoint Tutorials
==================

How to extract NARF keypoint from a range image
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
In this tutorial, we will learn how to extract NARF keypoints from a range image.

* `Original <http://pointclouds.org/documentation/tutorials/narf_keypoint_extraction.php#narf-keypoint-extraction>`_ \
* TestCode : examples/official/keypoints/narf_keypoint_extraction.py


