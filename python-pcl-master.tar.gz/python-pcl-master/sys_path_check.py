# -*- coding: utf-8 -*-
import sys

print(sys.path)