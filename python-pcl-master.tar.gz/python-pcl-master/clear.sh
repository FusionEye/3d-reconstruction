sudo rm pcl/_pcl.cpp
sudo rm pcl/_pcl.pyd
sudo rm pcl/_pcl_172.cpp
sudo rm pcl/_pcl_172.pyd
sudo rm pcl/_pcl_180.cpp
sudo rm pcl/_pcl_180.pyd
sudo rm pcl/pcl_registration_160.cpp
sudo rm pcl/pcl_registration_160.pyd
sudo rm pcl/pcl_registration_172.cpp
sudo rm pcl/pcl_registration_172.pyd
sudo rm pcl/pcl_registration_180.cpp
sudo rm pcl/pcl_registration_180.pyd
sudo rm pcl/pcl_visualization.cpp
sudo rm pcl/pcl_visualization.pyd
sudo rm pcl/pcl_grabber.cpp
sudo rm pcl/pcl_grabber.pyd
sudo rm pcl/pcl_grabber_180.cpp
sudo rm pcl/pcl_grabber_180.pyd
sudo rm -rf build
sudo rm -rf python_pcl.egg-info
sudo pip uninstall python-pcl -y
