python setup.py build_ext -i
python setup.py install
nosetests